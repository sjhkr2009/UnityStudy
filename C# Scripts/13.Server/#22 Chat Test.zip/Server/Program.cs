﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Text;
using ServerCore;

namespace Server
{
	
	class Program
	{
		static Listener _listener = new Listener();

		// + 추가된 부분
		// 어디서나 접근이 가능하도록 GameRoom을 생성해둔다.
		// 나중에는 여러 개의 Room을 매니저를 통해 별도로 제어할 것이다.
		public static GameRoom Room = new GameRoom();

		static void Main(string[] args)
		{
			Console.WriteLine("----- Server -----");

			// - 삭제된 부분
			// 패킷에 따른 콜백 함수 등록을 Main에서 하면 잊어버릴 위험이 있으니, 매니저에서 자체적으로 하게 변경
			//PacketManager.Instance.Register();

			string host = Dns.GetHostName();
			IPHostEntry ipHost = Dns.GetHostEntry(host);
			IPAddress ipAdr = ipHost.AddressList[0];
			IPEndPoint endPoint = new IPEndPoint(ipAdr, 7777);

			// * 수정된 부분
			// 람다 함수 대신 세션 매니저를 통해 생성한다.
			_listener.Init(endPoint, SessionManager.Instance.Generate);

			while (true)
			{
				// 프로그램 종료 방지를 위한 무한루프
			}
		}
	}
}
