using System;
using System.Collections.Generic;
using System.Text;
using ServerCore;

class PacketManager
{
	// * 수정된 부분
	#region Singleton
	// 패킷 매니저는 new로 생성하고, 생성자를 통해 Register()를 호출한다. 
	static PacketManager _instance = new PacketManager();
	public static PacketManager Instance => _instance;

	// 외부에서 새로 생성할 수 없도록 private 생성자 사용
	private PacketManager()
	{
		Register();
	}
	#endregion
	//---------------------------------------------------

	Dictionary<ushort, Action<PacketSession, ArraySegment<byte>>> _onReceive = new Dictionary<ushort, Action<PacketSession, ArraySegment<byte>>>();
	Dictionary<ushort, Action<PacketSession, IPacket>> _handler = new Dictionary<ushort, Action<PacketSession, IPacket>>();

	public void Register()
	{
		_onReceive.Add((ushort)PacketID.C_Chat, MakePacket<C_Chat>);
		_handler.Add((ushort)PacketID.C_Chat, PacketHandler.C_ChatHandler);

	}

	public void OnRecvPacket(PacketSession session, ArraySegment<byte> buffer)
	{
		ushort count = 0;

		// 무슨 패킷인지는 파악해야 하니 헤더 부분은 직접 읽어야 한다.
		ushort size = BitConverter.ToUInt16(buffer.Array, buffer.Offset);
		count += sizeof(ushort);
		ushort id = BitConverter.ToUInt16(buffer.Array, buffer.Offset + count);
		count += sizeof(ushort);

		Action<PacketSession, ArraySegment<byte>> action = null;
		if (_onReceive.TryGetValue(id, out action))
			action(session, buffer);
	}

	void MakePacket<T>(PacketSession session, ArraySegment<byte> buffer) where T : IPacket, new()
	{
		T packet = new T();
		packet.DeSerialize(buffer);

		Action<PacketSession, IPacket> action = null;
		if (_handler.TryGetValue(packet.Protocol, out action))
			action(session, packet);
	}
}