﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Text;
using ServerCore;

namespace Server
{
	class ClientSession : PacketSession
	{
		public int SessionId { get; set; }

		// 자신이 입장한 방을 가리키는 변수
		public GameRoom Room { get; set; }

		public override void OnConnected(EndPoint endPoint)
		{
			Console.WriteLine($"{endPoint}가 접속했습니다.");

			// + 추가된 부분
			// 접속한 유저를 방에 입장시킨다.
			Program.Room.Enter(this);

			// - 삭제된 부분
			// 이전에 테스트를 위해 연결 5초 후 자동으로 DIsconnect했던 부분은 지운다.
			//Thread.Sleep(5000);
			//Disconnect();
		}

		public override void OnDisconnected(EndPoint endPoint)
		{
			// + 추가된 부분
			// 세션을 세션 매니저가 관리하게 변경했으니, 연결 해제 시 세션 매니저에 해제를 요청한다.
			SessionManager.Instance.Remove(this);
			// 방에서도 퇴장 처리한다.
			if(Room != null)
			{
				Room.Leave(this);
				Room = null;
			}

			Console.WriteLine($"{endPoint}의 접속이 종료되었습니다.");
		}

		public override void OnReceivePacket(ArraySegment<byte> buffer)
		{
			PacketManager.Instance.OnRecvPacket(this, buffer);
		}

		public override void OnSend(int byteCount)
		{
			// 로그가 많아질테니 이 부분은 주석 처리
			//Console.WriteLine($"전송된 바이트: {byteCount}");
		}
	}

}
