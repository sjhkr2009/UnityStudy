﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server
{
	// 클라이언트 세션이 입장할 게임 채널의 역할을 하는 클래스.
	// 입장과 퇴장, 채팅 메시지 전송이 가능하다.
	class GameRoom
	{
		List<ClientSession> _sessions = new List<ClientSession>();

		object _lock = new object();
		public void Enter(ClientSession session)
		{
			lock(_lock)
			{
				_sessions.Add(session);
				session.Room = this;
			}
		}

		public void Leave(ClientSession session)
		{
			lock(_lock)
			{
				_sessions.Remove(session);
			}
		}

		public void Broadcast(ClientSession session, string chat)
		{
			// 서버에서 보낼 패킷을 조립하고 직렬화한다.
			S_Chat packet = new S_Chat();
			packet.playerId = session.SessionId;
			packet.chat = $"[Player {packet.playerId}] : {chat}";
			ArraySegment<byte> segment = packet.Serialize();

			// 모든 클라이언트에 전송한다.
			// 다른 스레드와 공유하고 있는 부분은 lock을 걸고 접근해야 한다.
			lock(_lock)
			{
				foreach (ClientSession s in _sessions)
					s.Send(segment);
			}
		}
	}
}
