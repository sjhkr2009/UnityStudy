﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Net.Sockets;
using System.Net;
using System.Text;

namespace ServerCore
{
	public abstract class PacketSession : Session
	{
		public static readonly int HeaderSize = 2;
		
		public sealed override int OnReceive(ArraySegment<byte> buffer)
		{
			int processLen = 0;

			while (true)
			{
				if (buffer.Count < HeaderSize)
					break;

				ushort dataSize = BitConverter.ToUInt16(buffer.Array, buffer.Offset);
				if (buffer.Count < dataSize)
					break;

				OnReceivePacket(new ArraySegment<byte>(buffer.Array, buffer.Offset, dataSize));

				processLen += dataSize;
				buffer = new ArraySegment<byte>(buffer.Array, buffer.Offset + dataSize, buffer.Count - dataSize);
			}
			
			return processLen;
		}
		public abstract void OnReceivePacket(ArraySegment<byte> buffer);
	}
	

	//----------------------------------------------------------------------------------------------

	public abstract class Session
	{
		Socket _socket;
		int _disconnected = 0;

		ReceiveBuffer _receiveBuffer = new ReceiveBuffer(1024);

		SocketAsyncEventArgs _sendArgs = new SocketAsyncEventArgs();
		SocketAsyncEventArgs _receiveArgs = new SocketAsyncEventArgs();

		object _lock = new object();
		
		Queue<ArraySegment<byte>> _sendQueue = new Queue<ArraySegment<byte>>();
		List<ArraySegment<byte>> _pendingList = new List<ArraySegment<byte>>();

		public abstract void OnConnected(EndPoint endPoint);
		public abstract int OnReceive(ArraySegment<byte> buffer);
		public abstract void OnSend(int byteCount);
		public abstract void OnDisconnected(EndPoint endPoint);

		// + 추가된 부분
		// Disconnect할 때 컨테이너에 쌓여있는 데이터도 비워준다. Disconnect()에서 호출된다.
		void Clear()
		{
			lock(_lock)
			{
				_sendQueue.Clear();
				_pendingList.Clear();
			}
		}

		public void Init(Socket socket, int bufferSize = 1024)
		{
			_socket = socket;

			_sendArgs.Completed += new EventHandler<SocketAsyncEventArgs>(OnSendCompleted);
			_receiveArgs.Completed += new EventHandler<SocketAsyncEventArgs>(OnReceiveCompleted);

			RegisterReceive();
		}

		public void Send(ArraySegment<byte> sendBuff)
		{
			lock (_lock)
			{
				_sendQueue.Enqueue(sendBuff);
				if (_pendingList.Count == 0)
					RegisterSend();
			}
		}

		// Disconnect에는 Interlocked로 예외 처리를 했지만, Send에는 하지 않았다.
		// 연결이 끊김과 동시에 Send/Receive가 호출되면 크래시가 날 수 있다.
		public void Disconnect()
		{
			if (Interlocked.Exchange(ref _disconnected, 1) == 1) 
				return;

			OnDisconnected(_socket.RemoteEndPoint);
			_socket.Shutdown(SocketShutdown.Both);
			_socket.Close();

			// + 추가된 부분
			// 큐와 리스트에 저장된 내용 초기화
			Clear();
		}

		#region 네트워크 통신

		void RegisterSend()
		{
			// + 추가된 부분
			// Disconnect에 의한 예외 처리
			if (_disconnected == 1)
				return;
			//------------------------------------------

			while (_sendQueue.Count > 0)
			{
				ArraySegment<byte> buffer = _sendQueue.Dequeue();
				_pendingList.Add(buffer);
			}
			_sendArgs.BufferList = _pendingList;

			// + 수정된 부분
			// 여기까지 넘어왔는데 다른 스레드가 Disconnect할 수도 있으므로 위의 예외 처리로는 부족하다.
			// 아예 Send 과정을 try-catch로 묶어 준다.
			try
			{
				bool pending = _socket.SendAsync(_sendArgs);
				if (!pending)
					OnSendCompleted(null, _sendArgs);
			}
			catch(Exception e)
			{
				// 실제로는 콘솔 로그가 아닌 에러 파일로 출력해야겠지만, 일단 콘솔 로그로 찍어본다.
				Console.WriteLine($"Register Send Failed! {e} : {e.Message}");
			}
		}

		void OnSendCompleted(object sender, SocketAsyncEventArgs args)
		{
			lock (_lock)
			{
				if (args.BytesTransferred > 0 && args.SocketError == SocketError.Success)
				{
					OnSend(args.BytesTransferred);

					_sendArgs.BufferList = null;
					_pendingList.Clear();
					
					if (_sendQueue.Count > 0)
						RegisterSend();
				}
				else Disconnect();
			}
		}

		void RegisterReceive()
		{
			// + 추가된 부분
			// Disconnect에 의한 예외 처리
			if (_disconnected == 1)
				return;
			//------------------------------------------

			_receiveBuffer.Clear();
			ArraySegment<byte> segment = _receiveBuffer.WriteSegment;
			_receiveArgs.SetBuffer(segment.Array, segment.Offset, segment.Count);


			// + 수정된 부분
			// 여기까지 넘어왔는데 다른 스레드가 Disconnect할 수도 있으므로 위의 예외 처리로는 부족하다.
			// 아예 Receive 과정을 try-catch로 묶어 준다.
			try
			{
				bool pending = _socket.ReceiveAsync(_receiveArgs);
				if (!pending)
					OnReceiveCompleted(null, _receiveArgs);
			}
			catch (Exception e)
			{
				Console.WriteLine($"Register Send Failed! {e} : {e.Message}");
			}
			
		}

		void OnReceiveCompleted(object sender, SocketAsyncEventArgs args)
		{
			if (args.BytesTransferred > 0 && args.SocketError == SocketError.Success)
			{
				try
				{
					if (!_receiveBuffer.OnWrite(args.BytesTransferred))
					{
						Disconnect();
						return;
					}

					int processLen = OnReceive(_receiveBuffer.ReadSegment);
					if(processLen < 0 || processLen > _receiveBuffer.DataSize)
					{
						Disconnect();
						return;
					}
					if(!_receiveBuffer.OnRead(processLen))
					{
						Disconnect();
						return;
					}

					RegisterReceive();
				}
				catch (Exception e)
				{
					Console.WriteLine($"OnReceiveCompleted failed : {e}");
				}
			}
			else Disconnect();
		}

		#endregion
	}
}
