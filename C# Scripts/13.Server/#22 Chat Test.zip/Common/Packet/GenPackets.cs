using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using ServerCore;

public enum PacketID 
{
	C_Chat = 1,
	S_Chat = 2,
	
}

interface IPacket
{
	ushort Protocol { get; }
	void DeSerialize(ArraySegment<byte> arr);
	ArraySegment<byte> Serialize();
}


class C_Chat : IPacket
{
	public ushort Protocol => (ushort)PacketID.C_Chat;

	public string chat;

	public ArraySegment<byte> Serialize()
	{
		ArraySegment<byte> arr = SendBufferHelper.Open(4096);
		Span<byte> span = new Span<byte>(arr.Array, arr.Offset, arr.Count);

		ushort count = 0;
		bool success = true;

		count += sizeof(ushort);
		success &= BitConverter.TryWriteBytes(span.Slice(count, span.Length - count), (ushort)PacketID.C_Chat);
		count += sizeof(ushort);
		
		ushort chatLen = (ushort)Encoding.Unicode.GetBytes(chat, 0, chat.Length, arr.Array, arr.Offset + count + sizeof(ushort));
		success &= BitConverter.TryWriteBytes(span.Slice(count, span.Length - count), chatLen);
		count += sizeof(ushort);
		count += chatLen;

		success &= BitConverter.TryWriteBytes(span, count);

		if (!success)
			return null;

		return SendBufferHelper.Close(count);
	}
	public void DeSerialize(ArraySegment<byte> arr)
	{
		ushort count = 0;
		count += sizeof(ushort);
		count += sizeof(ushort);

		ReadOnlySpan<byte> span = new ReadOnlySpan<byte>(arr.Array, arr.Offset, arr.Count);

		ushort chatLen = BitConverter.ToUInt16(span.Slice(count, span.Length - count));
		count += sizeof(ushort);
		this.chat = Encoding.Unicode.GetString(span.Slice(count, chatLen));
		count += chatLen;
	}
}

class S_Chat : IPacket
{
	public ushort Protocol => (ushort)PacketID.S_Chat;

	public int playerId;
	public string chat;

	public ArraySegment<byte> Serialize()
	{
		ArraySegment<byte> arr = SendBufferHelper.Open(4096);
		Span<byte> span = new Span<byte>(arr.Array, arr.Offset, arr.Count);

		ushort count = 0;
		bool success = true;

		count += sizeof(ushort);
		success &= BitConverter.TryWriteBytes(span.Slice(count, span.Length - count), (ushort)PacketID.S_Chat);
		count += sizeof(ushort);
		
		success &= BitConverter.TryWriteBytes(span.Slice(count, span.Length - count), playerId);
		count += sizeof(int);
		ushort chatLen = (ushort)Encoding.Unicode.GetBytes(chat, 0, chat.Length, arr.Array, arr.Offset + count + sizeof(ushort));
		success &= BitConverter.TryWriteBytes(span.Slice(count, span.Length - count), chatLen);
		count += sizeof(ushort);
		count += chatLen;

		success &= BitConverter.TryWriteBytes(span, count);

		if (!success)
			return null;

		return SendBufferHelper.Close(count);
	}
	public void DeSerialize(ArraySegment<byte> arr)
	{
		ushort count = 0;
		count += sizeof(ushort);
		count += sizeof(ushort);

		ReadOnlySpan<byte> span = new ReadOnlySpan<byte>(arr.Array, arr.Offset, arr.Count);

		this.playerId = BitConverter.ToInt32(span.Slice(count, span.Length - count));
		count += sizeof(int);
		ushort chatLen = BitConverter.ToUInt16(span.Slice(count, span.Length - count));
		count += sizeof(ushort);
		this.chat = Encoding.Unicode.GetString(span.Slice(count, chatLen));
		count += chatLen;
	}
}

